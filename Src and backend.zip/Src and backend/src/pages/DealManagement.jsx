import React, { useEffect, useState } from 'react';

function DealManagement() {
  const [deals, setDeals] = useState([]);
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({
    name: '', description: '', price: '', productItems: [], isVisible: true
  });

  useEffect(() => {
    fetch('/api/deals').then(r => r.json()).then(setDeals);
    fetch('/api/products?adminView=true').then(r => r.json()).then(setProducts);
  }, []);

  function toggleProductItem(productId, sizeName, crustName) {
    setForm(f => {
      const exists = f.productItems.find(
        i => i.productId === productId && i.sizeName === sizeName && i.crustName === crustName
      );
      if (exists) return { ...f, productItems: f.productItems.filter(
        i => !(i.productId === productId && i.sizeName === sizeName && i.crustName === crustName)
      ) };
      return { ...f, productItems: [...f.productItems, { productId, sizeName, crustName, quantity: 1 }] };
    });
  }
  function setQuantity(idx, quantity) {
    setForm(f => ({
      ...f,
      productItems: f.productItems.map((it, i) => i === idx ? { ...it, quantity } : it)
    }));
  }
  function handleChange(e) {
    setForm(f => ({ ...f, [e.target.name]: e.target.value }));
  }
  async function submit(e) {
    e.preventDefault();
    await fetch('/api/deals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...form, price: Number(form.price) })
    });
    setForm({ name: '', description: '', price: '', productItems: [], isVisible: true });
    fetch('/api/deals').then(r => r.json()).then(setDeals);
  }

  function toggleVisibility(id, vis) {
    fetch(`/api/deals/${id}/visibility`, { method: 'PATCH' }).then(() =>
      fetch('/api/deals').then(r => r.json()).then(setDeals)
    );
  }

  return (
    <div style={{ maxWidth: 700, margin: 'auto', padding: 24 }}>
      <h2>Deal Management</h2>
      <form onSubmit={submit} style={{ background: '#fafafa', padding: 16, borderRadius: 8, marginBottom: 32 }}>
        <input name="name" placeholder="Deal Name" value={form.name} onChange={handleChange} required style={{ width: '100%', marginBottom: 8 }} />
        <input name="price" placeholder="Deal Price" type="number" value={form.price} onChange={handleChange} required style={{ width: '100%', marginBottom: 8 }} />
        <textarea name="description" placeholder="Description" value={form.description} onChange={handleChange} style={{ width: '100%', marginBottom: 8 }} />
        <div>
          <b>Included Products:</b>
          {products.map(p =>
            p.sizeVariants.map(sv =>
              <div key={p._id + sv.sizeName}>
                <input type="checkbox"
                  checked={!!form.productItems.find(it => it.productId === p._id && it.sizeName === sv.sizeName)}
                  onChange={() => toggleProductItem(p._id, sv.sizeName, null)}
                />
                {p.name} ({sv.sizeName})
              </div>
            )
          )}
        </div>
        <button type="submit">Create Deal</button>
      </form>
      <h3>Active Deals</h3>
      <table border={1} cellPadding={8}>
        <thead><tr>
          <th>Name</th><th>Products</th><th>Price</th><th>Status</th><th>Actions</th>
        </tr></thead>
        <tbody>
          {deals.map(d =>
            <tr key={d._id}>
              <td>{d.name}</td>
              <td>
                {d.productItems.map((it, i) =>
                  <div key={i}>
                    {it.productId?.name} ({it.sizeName}) x{it.quantity}
                  </div>
                )}
              </td>
              <td>{d.price}</td>
              <td>{d.isVisible ? "Shown" : "Hidden"}</td>
              <td><button onClick={() => toggleVisibility(d._id, d.isVisible)}>{d.isVisible ? "Hide" : "Show"}</button></td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default DealManagement;