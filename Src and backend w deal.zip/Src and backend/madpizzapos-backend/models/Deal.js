const mongoose = require('mongoose');

const dealSchema = new mongoose.Schema({
  name: { type: String, required: true, unique: true },
  description: { type: String },
  price: { type: Number, required: true, min: 0 },
  productItems: [{
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    sizeName: { type: String, required: true }, // must match product's sizeVariants
    crustName: { type: String }, // optional, for pizzas etc
    quantity: { type: Number, required: true, min: 1, default: 1 }
  }],
  isVisible: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Deal', dealSchema);