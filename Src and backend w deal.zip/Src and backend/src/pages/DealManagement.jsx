import React, { useEffect, useState } from "react";
import "./ProductManagement.css"; // Reuse admin style for a consistent look

const api = (path, opts) =>
  fetch(path, opts).then((res) => res.json());

function DealManagement() {
  const [deals, setDeals] = useState([]);
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({
    name: "",
    description: "",
    price: "",
    productItems: [],
    isVisible: true,
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    refresh();
  }, []);

  function refresh() {
    setLoading(true);
    Promise.all([
      api("/api/deals"),
      api("/api/products?adminView=true"),
    ]).then(([d, p]) => {
      setDeals(d);
      setProducts(p);
      setLoading(false);
    });
  }

  function toggleProductItem(productId, sizeName, crustName) {
    setForm((f) => {
      const idx = f.productItems.findIndex(
        (i) =>
          i.productId === productId &&
          i.sizeName === sizeName &&
          ((i.crustName || "") === (crustName || ""))
      );
      if (idx !== -1) {
        // Remove
        const arr = [...f.productItems];
        arr.splice(idx, 1);
        return { ...f, productItems: arr };
      }
      // Add
      return {
        ...f,
        productItems: [
          ...f.productItems,
          { productId, sizeName, crustName, quantity: 1 },
        ],
      };
    });
  }

  function setQuantity(idx, quantity) {
    setForm((f) => ({
      ...f,
      productItems: f.productItems.map((it, i) =>
        i === idx ? { ...it, quantity } : it
      ),
    }));
  }

  function handleChange(e) {
    setForm((f) => ({
      ...f,
      [e.target.name]: e.target.value,
    }));
  }

  async function submit(e) {
    e.preventDefault();
    await api("/api/deals", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...form,
        price: Number(form.price),
        productItems: form.productItems.map((i) => ({
          ...i,
          quantity: Number(i.quantity) || 1,
        })),
      }),
    });
    setForm({
      name: "",
      description: "",
      price: "",
      productItems: [],
      isVisible: true,
    });
    refresh();
  }

  function toggleVisibility(id) {
    api(`/api/deals/${id}/visibility`, { method: "PATCH" }).then(refresh);
  }

  return (
    <div className="product-management-container">
      <h2 className="pm-title">Deal Management</h2>
      <form className="pm-form" onSubmit={submit}>
        <div className="pm-form-row">
          <label>Deal Name</label>
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            required
            className="pm-form-input"
          />
        </div>
        <div className="pm-form-row">
          <label>Description</label>
          <textarea
            name="description"
            value={form.description}
            onChange={handleChange}
            className="pm-form-input"
          />
        </div>
        <div className="pm-form-row">
          <label>Price</label>
          <input
            name="price"
            type="number"
            value={form.price}
            onChange={handleChange}
            required
            min="0"
            className="pm-form-input"
          />
        </div>

        <div className="pm-form-row">
          <label>Included Products:</label>
          <div className="pm-product-select-list">
            {products.map((prod) =>
              prod.sizeVariants.map((sv) =>
                (prod.crustOptions && prod.crustOptions.length > 0
                  ? prod.crustOptions
                  : [null]
                ).map((crust) => {
                  const selected = !!form.productItems.find(
                    (i) =>
                      i.productId === prod._id &&
                      i.sizeName === sv.sizeName &&
                      ((i.crustName || "") === (crust || ""))
                  );
                  const idx = form.productItems.findIndex(
                    (i) =>
                      i.productId === prod._id &&
                      i.sizeName === sv.sizeName &&
                      ((i.crustName || "") === (crust || ""))
                  );
                  return (
                    <div
                      className={
                        "pm-product-checkbox" + (selected ? " pm-selected" : "")
                      }
                      key={
                        prod._id +
                        sv.sizeName +
                        (crust ? `-${crust}` : "")
                      }
                    >
                      <input
                        type="checkbox"
                        checked={selected}
                        onChange={() =>
                          toggleProductItem(prod._id, sv.sizeName, crust)
                        }
                      />
                      {prod.name} ({sv.sizeName}
                      {crust ? `, ${crust}` : ""})
                      {selected && (
                        <input
                          type="number"
                          min={1}
                          value={form.productItems[idx].quantity}
                          style={{
                            width: 50,
                            marginLeft: 8,
                            borderRadius: 4,
                            border: "1px solid #ccc",
                          }}
                          onChange={(e) =>
                            setQuantity(idx, e.target.value)
                          }
                        />
                      )}
                    </div>
                  );
                })
              )
            )}
          </div>
        </div>
        <div className="pm-form-row">
          <button
            type="submit"
            className="pm-form-button"
            disabled={loading}
            style={{ marginTop: 16 }}
          >
            {loading ? "Saving..." : "Create Deal"}
          </button>
        </div>
      </form>
      <h3 className="pm-title" style={{marginTop: 32}}>Active Deals</h3>
      <div className="pm-table-container">
        <table className="pm-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Products</th>
              <th>Price</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {deals.map((d) => (
              <tr key={d._id}>
                <td>{d.name}</td>
                <td>
                  {d.productItems.map((it, i) => (
                    <div key={i}>
                      {it.productId?.name || "Product"} ({it.sizeName}
                      {it.crustName ? `, ${it.crustName}` : ""}) x{it.quantity}
                    </div>
                  ))}
                </td>
                <td>{d.price}</td>
                <td>
                  <span
                    className={
                      d.isVisible
                        ? "pm-status pm-status-active"
                        : "pm-status pm-status-inactive"
                    }
                  >
                    {d.isVisible ? "Visible" : "Hidden"}
                  </span>
                </td>
                <td>
                  <button
                    className="pm-form-button"
                    style={{
                      background: d.isVisible ? "#f44336" : "#4caf50",
                    }}
                    onClick={() => toggleVisibility(d._id)}
                  >
                    {d.isVisible ? "Hide" : "Show"}
                  </button>
                </td>
              </tr>
            ))}
            {!deals.length && (
              <tr>
                <td colSpan={5} style={{ textAlign: "center" }}>
                  No deals found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default DealManagement;